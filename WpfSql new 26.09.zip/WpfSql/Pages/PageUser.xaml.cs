﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfSql.Classes;

namespace WpfSql.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageUser.xaml
    /// </summary>
    public partial class PageUser : Page
    {
        public PageUser()
        {
            InitializeComponent();
            DGridPersona.ItemsSource = basedEntities.GetContext().Persona.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new EditPage((sender as Button).DataContext as Persona));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new EditPage(null));
        }
        private void Page_InvisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                basedEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridPersona.ItemsSource = basedEntities.GetContext().Persona.ToList();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var usersForRemoving = DGridPersona.SelectedItems.Cast<Persona>.ToList();
            if(MessageBox.Show($"Удалить{usersForRemoving.Count()}пользователей?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                try
                {
                    basedEntities.GetContext().Persona.RemoveRange(usersForRemoving);
                    basedEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridPersona.ItemsSource = basedEntities.GetContext().Persona.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
        }
    }
}
